/*
 * Copyright 2018, Zetyun StreamTau All rights reserved.
 */

package com.zetyun.rt.cache.operator;

import com.zetyun.rt.cache.service.SqlSaveToIgniteUtils;
import com.zetyun.rt.cache.service.SqlCacheTableBuilderUtils;
import com.zetyun.rt.common.error.RtException;
import com.zetyun.rt.common.schema.Schema;
import com.zetyun.rt.models.protocol.ignite.IgniteSqlParameters;
import com.zetyun.rt.sdk.action.MapAction;
import com.zetyun.rt.sdk.internal.service.ignite.IgniteService;
import com.zetyun.rt.sdk.model.RtEvent;
import com.zetyun.rt.sdk.operator.OperatorContext;
import com.zetyun.rt.sdk.service.sqlcache.SqlCacheTable;
import org.apache.commons.lang3.StringUtils;
import org.apache.ignite.Ignite;
import org.apache.ignite.configuration.CacheConfiguration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import javax.cache.Cache;


public class SqlSaveToIgniteAction extends MapAction {
    private transient IgniteSqlParameters igniteSqlParameters;
    private transient Ignite ignite;
    private static final Logger logger = LoggerFactory.getLogger(SqlSaveToIgniteAction.class);

    @Override
    public void init(OperatorContext context) {
        super.init(context);
        igniteSqlParameters = context.getArguments(IgniteSqlParameters.class);
        IgniteService igniteService = context.getService(IgniteService.class);
        ignite = igniteService.getIgnite();
        if (!StringUtils.isBlank(igniteSqlParameters.getIgniteTemplateFileName())) {
            buildCacheConfigFromTemplate(igniteSqlParameters);
        }
        Connection con = null;
        try {
            con = obtainIgniteServerConnection(ignite);
            updateCacheSchema(igniteSqlParameters, con);
        }
        catch (Exception ex) {
            throw RtException.from(ex);
        }
        finally {
            try {
                con.close();
            }
            catch (Exception ex) {
                //ignore exception
            }
        }



    }

    protected void buildCacheConfigFromTemplate(IgniteSqlParameters igniteSqlParameters) {
        CacheConfiguration configuration = SqlSaveToIgniteUtils.buildWithTemplate(
            igniteSqlParameters.getConfigBeanId(), igniteSqlParameters.getIgniteTemplateFileName(),
            Object.class, Object.class);
        ignite.addCacheConfiguration(configuration);
    }

    protected void updateCacheSchema(IgniteSqlParameters igniteSqlParameters, Connection con) {
        String cacheName = igniteSqlParameters.getCacheName();
        Schema currentSchema = igniteSqlParameters.getSchema();
        SqlCacheTable newTable = SqlCacheTableBuilderUtils.buildSqlCacheTableFromSchema(currentSchema);
        logger.debug("Generated table from schema: {} with cache name");
        Cache cache = ignite.cache(cacheName);
        if (cache != null) {
            CacheConfiguration cacheConfig = (CacheConfiguration) cache.getConfiguration(CacheConfiguration.class);
            List<SqlCacheTable> prevTables = SqlCacheTableBuilderUtils.buildSqlCacheTableFromCacheConfig(cacheConfig);
            logger.debug("Loading cache config for cache name: {}, cache config: {}, generated tables: {}",
                cacheName, cacheConfig, prevTables);
            boolean isCompatibleSchemaChange = SqlCacheTableBuilderUtils.isCompartibleChange(prevTables.get(0),
                newTable);
            if (isCompatibleSchemaChange) {
                List<String> alterTableSqls = SqlCacheTableBuilderUtils.generateAlterTableSql(cacheName,
                    prevTables.get(0), newTable);
                logger.info("Generated alter table sql: {}", alterTableSqls);
                List<String> additionalIndexSqls = SqlCacheTableBuilderUtils.generateCreateIndexSql(cacheName,
                    prevTables.get(0), newTable);
                logger.info("Generated additional index sqls: {}", additionalIndexSqls);
                List<String> allSqls = new ArrayList<String>();
                allSqls.addAll(alterTableSqls);
                allSqls.addAll(additionalIndexSqls);
                executeIgniteDdlSqls(con, allSqls);
            }
        }
        else {
            String createTableSql = SqlCacheTableBuilderUtils.generateCreateTableSql(cacheName, newTable);
            logger.info("Generated create table sql: {}", createTableSql);
            List<String> createIndexSqls = SqlCacheTableBuilderUtils.generateCreateIndexSql(cacheName, newTable);
            logger.info("Generated additional index sqls: {}", createIndexSqls);
            List<String> allSqls = new ArrayList<String>();
            allSqls.add(createTableSql);
            allSqls.addAll(createIndexSqls);
            executeIgniteDdlSqls(con, allSqls);
        }
    }

    protected Connection obtainIgniteServerConnection(Ignite ignite) throws Exception {
        Class.forName("org.apache.ignite.IgniteJdbcThinDriver");
        String connectionStr = "jdbc:ignite:thin://{0}";
        Set<String> hosts = ignite.cluster().nodes().stream().filter((n) -> { return !n.isClient(); })
            .map((n) -> { return n.hostNames().iterator().next(); }).collect(Collectors.toSet());
        String conUrl = MessageFormat.format(connectionStr, String.join(",", hosts));
        logger.debug("Ignite jdbc connection string is : {}", conUrl);
        Connection conn = DriverManager.getConnection(conUrl);
        return conn;
    }

    protected void executeIgniteDdlSqls(Connection connection, List<String> sqls) {
        try {
            for (String sql : sqls) {
                PreparedStatement createTablePs = null;
                try {
                    createTablePs = connection.prepareStatement(sql);
                    createTablePs.execute();
                }
                finally {
                    if (createTablePs != null) {
                        createTablePs.close();
                    }
                }
            }
        }
        catch (Exception ex) {
            logger.error("Error executing ignite ddl sqls", ex);
        }
    }

    @Override
    public RtEvent apply(RtEvent in) {
        igniteSqlParameters.getCreateSql();
        return in;
    }

}
