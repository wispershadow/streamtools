/*
 * Copyright 2018, Zetyun StreamTau All rights reserved.
 */

package com.zetyun.rt.cache.operator;

import com.zetyun.rt.cache.service.SchemaIgniteCacheService;
import com.zetyun.rt.common.Converter;
import com.zetyun.rt.common.PropertySetter;
import com.zetyun.rt.common.impl.BeanPropertySetter;
import com.zetyun.rt.common.impl.MapBeanPopulateUtils;
import com.zetyun.rt.meta.annotation.ActionMeta;
import com.zetyun.rt.models.constants.OperatorNames;
import com.zetyun.rt.models.protocol.ignite.IgniteCacheMappingCfg;
import com.zetyun.rt.models.protocol.ignite.IgniteCacheParameters;
import com.zetyun.rt.rule.expression.ExpressionMapBeanPopulator;
import com.zetyun.rt.sdk.action.MapAction;
import com.zetyun.rt.sdk.internal.service.ignite.IgniteWrapper;
import com.zetyun.rt.sdk.model.RtEvent;
import com.zetyun.rt.sdk.operator.OperatorContext;
import com.zetyun.rt.sdk.service.cache.Cache;
import com.zetyun.rt.sdk.service.cache.CachePool;
import com.zetyun.rt.sdk.service.expression.ExpressionEvaluator;

import org.apache.ignite.configuration.CacheConfiguration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.beans.PropertyDescriptor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

@ActionMeta(
    id = OperatorNames.IGNITECACHE,
    tags = {"cache"},
    category = "transform",
    name = "AdapterOfIgnite",
    description = "create/read/write data to ignite",
    configClass = IgniteCacheParameters.class)
public class CacheSaveToIgniteAction extends MapAction {
    private transient ExpressionMapBeanPopulator expressionMapBeanPopulator;
    private transient PropertySetter beanPropertySetter;
    private transient IgniteCacheParameters igniteCacheParameters;

    private Cache<Object, Object> cache;

    private static final Logger logger = LoggerFactory.getLogger(CacheSaveToIgniteAction.class);

    @Override
    @SuppressWarnings("unchecked")
    public void init(OperatorContext context) {
        super.init(context);
        ExpressionEvaluator evaluator = context.getService(ExpressionEvaluator.class);
        expressionMapBeanPopulator = new ExpressionMapBeanPopulator(evaluator);
        beanPropertySetter = new BeanPropertySetter();
        igniteCacheParameters = context.getArguments(IgniteCacheParameters.class);

        CacheConfiguration cacheConfig = SchemaIgniteCacheService.getCacheConfiguration(igniteCacheParameters);
        IgniteWrapper igniteWrapper = (IgniteWrapper)context.getService(CachePool.class);
        cache = (Cache)igniteWrapper.getOrCreateCache(cacheConfig);
    }

    private IgniteCacheMappingCfg getCacheMappingConfig() {
        IgniteCacheParameters parameters = getContext().getArguments(IgniteCacheParameters.class);
        return parameters.getCacheMapping();
    }

    @Override
    public RtEvent apply(RtEvent in) {
        IgniteCacheMappingCfg igniteCacheMappingCfg = getCacheMappingConfig();
        Object cacheData = putValueToCache(in, igniteCacheMappingCfg);
        RtEvent out = in;
        RtEvent convertedCacheData = convertCacheDataToRtEvent(cacheData);
        if (null != convertedCacheData)
        {
            out = convertedCacheData;
        }
        return out;
    }

    @Override
    public void close() throws Exception {
        super.close();
    }

    private Object putValueToCache(RtEvent in, IgniteCacheMappingCfg igniteCacheMappingCfg) {
        Object cacheRecordValue = convertRtEventToCacheValue(in, igniteCacheMappingCfg);
        Object cacheRecordKey = convertRtEventToCacheKey(in, cacheRecordValue);
        logger.debug("Putting value to cache key={}, value={}", cacheRecordKey, cacheRecordValue);
        cache.put(cacheRecordKey, cacheRecordValue);
        return cacheRecordValue;
    }

    private Object convertRtEventToCacheKey(RtEvent in, Object convertedRecord) {
        String converterClass = igniteCacheParameters.getKeyConversionClass();
        if (null != converterClass && !converterClass.trim().equals("")) {
            try {
                Class clz = this.getContext().getClassForName(converterClass);
                Converter<Map, Object> converter = (Converter<Map, Object>) clz.newInstance();
                return converter.convert(in.getMetricMap(), converterClass);
            } catch (Exception e) {
                logger.error("Error converting rule input with class " + converterClass, e);
                return null;
            }
        }

        if (null == convertedRecord) {
            logger.error("Cannot convert RtEvent to Cache Record!");
        } else {
            try {
                PropertyDescriptor pd =
                    new PropertyDescriptor(igniteCacheParameters.getKeyProperty(),
                        convertedRecord.getClass());
                Method method = pd.getReadMethod();
                return method.invoke(convertedRecord);
            } catch (Exception e) {
                logger.error("Cannot get Cache KeyValue");
            }
        }
        return null;
    }

    private Object convertRtEventToCacheValue(RtEvent in, IgniteCacheMappingCfg igniteCacheMappingCfg) {
        String converterClass = igniteCacheParameters.getObjectConversionClass();
        if (null != converterClass && !converterClass.trim().equals("")) {
            try {
                Class clz = this.getContext().getClassForName(converterClass);
                Converter<Map, Object> converter = (Converter<Map, Object>) clz.newInstance();
                return converter.convert(in.getMetricMap(), converterClass);
            } catch (Exception e) {
                logger.error("Error converting rule input with class " + converterClass, e);
                return null;
            }
        }

        Object converted = null;

        try {
            converted = this.getContext().getClassForName(igniteCacheParameters.getObjectClass()).newInstance();
        } catch (Exception e) {
            logger.error("Error creating convert object instance");
            return null;
        }

        if (null != igniteCacheMappingCfg) {
            Map<String, String> recordCacheMapping = igniteCacheMappingCfg.getRecordCacheMapping();
            if (null != recordCacheMapping && !recordCacheMapping.isEmpty()) {
                Map<String,String> transRecordCacheMapping = new HashMap<>();
                for (Map.Entry<String, String> entrySet : recordCacheMapping.entrySet()) {
                    transRecordCacheMapping.put(entrySet.getValue(),entrySet.getKey());
                }
                expressionMapBeanPopulator.populateBeanFromMap(in.getMetricMap(), converted, transRecordCacheMapping,
                    beanPropertySetter);
                return converted;
            }
        }

        MapBeanPopulateUtils.populateBeanFromMap(in.getMetricMap(), converted, beanPropertySetter);
        return converted;
    }

    private RtEvent convertCacheDataToRtEvent(Object out) {
        try {
            Class cacheDataClz = out.getClass();
            Field[] fields = cacheDataClz.getDeclaredFields();
            RtEvent rtEvent = new RtEvent();
            for (Field field : fields) {
                PropertyDescriptor pd = new PropertyDescriptor(field.getName(), cacheDataClz);
                Method rM = pd.getReadMethod();
                rtEvent.setValue(field.getName(), rM.invoke(out));
            }
            return rtEvent;
        } catch (Exception e) {
            logger.error("Transfer Cache Record To RtEvent Error", e);
        }
        return null;
    }
}
