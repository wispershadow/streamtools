/*
 * Copyright 2018, Zetyun StreamTau All rights reserved.
 */

package com.zetyun.rt.cache.error;

import com.zetyun.rt.common.error.RtError;

public enum IgniteCacheErrCode implements RtError {

    OK(0, "OK"),
    WRONG_CACHE_MODE(1, "Wrong cache mode name"),
    WRONG_CACHE_ATOMICITY_MODE(2, "Wrong cache atomicity mode name"),
    WRONG_CACHE_WRITE_SYNCHRONIZATION_MODE(3, "Wrong cache write synchronization mode"),
    ERROR_START_IGNITE(4, "Start Ignite error"),
    ERROR_GET_IGNITE(5, "Get Ignite error"),
    ERROR_CLOSE_IGNITE(6, "Close Ignite error"),
    NULL_IGNITE_OR_IGNITECACHE(7, "Ignite or IgniteCache NULL"),
    ERROR_CREATE_IGNITECACHE(8, "Create IgniteCache error"),
    ERROR_GET_IGNITECACHE(9, "Get IgniteCache error"),
    ERROR_CLOSE_IGNITECACHE(10, "Close IgniteCache error"),
    NULL_CACHE_KEY(11, "Cache Key is NULL"),
    NULL_CACHE_VALUE(12, "Cache Value is NULL");

    private int code;
    private String info;

    IgniteCacheErrCode(int code, String info) {
        this.code = code;
        this.info = info;
    }

    @Override
    public int getCode() {
        return code;
    }

    @Override
    public String getInfo() {
        return info;
    }
}
