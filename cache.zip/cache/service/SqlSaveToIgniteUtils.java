/*
 * Copyright 2018, Zetyun StreamTau All rights reserved.
 */

package com.zetyun.rt.cache.service;

import com.zetyun.rt.common.ConversionUtils;
import com.zetyun.rt.common.schema.Schema;
import com.zetyun.rt.sdk.model.RtEvent;
import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteBinary;
import org.apache.ignite.binary.BinaryObject;
import org.apache.ignite.binary.BinaryObjectBuilder;
import org.apache.ignite.configuration.CacheConfiguration;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.List;

public class SqlSaveToIgniteUtils {
    /**
     * build a cache config from template file.
     * @param templateBeanId template bean id
     * @param templateFile  tempalte file
     * @param keyType  key type
     * @param valueType value type
     * @param <K>  key generic
     * @param <V> value generic
     * @return  cache configuration
     */
    public static <K, V> CacheConfiguration<K, V> buildWithTemplate(String templateBeanId,
                                                                    String templateFile, Class<K> keyType,
                                                                    Class<V> valueType) {
        ClassPathXmlApplicationContext applicationContext =
            new ClassPathXmlApplicationContext(new String[]{templateFile});
        applicationContext.setClassLoader(Thread.currentThread().getContextClassLoader());
        CacheConfiguration igniteCacheConfig = (CacheConfiguration) applicationContext.getBean(templateBeanId);
        return igniteCacheConfig;
    }

    public static BinaryObject convertToBinaryObject(RtEvent event, Ignite ignite, Schema schema,
                                                     InsertSqlParseResult insertSqlParseResult) {
        insertSqlParseResult.getTableName();
    }


    private static BinaryObject convertToBinaryObject(RtEvent event, Ignite ignite,
                                                      String schemaName, List<String> columnNames,
                                                      List<String> attributeNames,
                                                      List<String> attributeTypes,
                                                      List<Boolean> nullable) {
        IgniteBinary binary = ignite.binary();
        BinaryObjectBuilder bldr = binary.builder(schemaName);
        for (int i = 0; i < attributeNames.size(); i++) {
            String attributeName = attributeNames.get(i);
            String attributeType = attributeTypes.get(i);
            String columnName = columnNames.get(i);
            Object object = buildObject(event, attributeName, attributeType);
            if (object != null) {
                bldr.setField(columnName, object);
            }
            else {
                if (!nullable.get(i)) {
                    throw new RuntimeException("Attribute " + attributeName + " is not nullable");
                }
            }
        }
        return bldr.build();
    }

    private static Object buildObject(RtEvent event, String attributeName, String attributeType) {
        Object attributeValue = event.getValue(attributeName);
        if (attributeValue == null) {
            return null;
        }
        return ConversionUtils.convertObj(attributeValue, attributeType);
    }



}
