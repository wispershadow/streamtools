/*
 * Copyright 2018, Zetyun StreamTau All rights reserved.
 */

package com.zetyun.rt.cache.service;

import org.apache.calcite.avatica.util.Casing;
import org.apache.calcite.avatica.util.Quoting;
import org.apache.calcite.sql.SqlBasicCall;
import org.apache.calcite.sql.SqlIdentifier;
import org.apache.calcite.sql.SqlInsert;
import org.apache.calcite.sql.SqlLiteral;
import org.apache.calcite.sql.SqlNode;
import org.apache.calcite.sql.SqlOperator;
import org.apache.calcite.sql.SqlUpdate;
import org.apache.calcite.sql.parser.SqlParser;
import org.apache.calcite.sql.parser.SqlParserImplFactory;
import org.apache.calcite.sql.parser.impl.SqlParserImpl;
import org.apache.calcite.sql.validate.SqlConformance;
import org.apache.calcite.sql.validate.SqlConformanceEnum;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

public class CalciteSqlUtils {
    private static final Logger logger = LoggerFactory.getLogger(CalciteSqlUtils.class);
    private static Quoting quoting = Quoting.DOUBLE_QUOTE;
    private static Casing unquotedCasing = Casing.UNCHANGED;
    private static Casing quotedCasing = Casing.UNCHANGED;
    private static SqlConformance conformance = SqlConformanceEnum.DEFAULT;

    /**
     * Get sql parser.
     * @param sql  sql
     * @return  sql parser
     */
    public static SqlParser getSqlParser(String sql) {
        return SqlParser.create(sql,
            SqlParser.configBuilder()
                .setParserFactory(parserImplFactory())
                .setQuoting(quoting)
                .setUnquotedCasing(unquotedCasing)
                .setQuotedCasing(quotedCasing)
                .setConformance(conformance)
                .build());
    }

    /**
     * convert insert sql parse result.
     * @param insertNode  insert node
     * @return  insert sql parse result
     */
    public static InsertSqlParseResult convertInsertSqlParseResult(SqlNode insertNode) {
        SqlInsert sqlInsert = (SqlInsert)insertNode;
        InsertSqlParseResult insertSqlParseResult = new InsertSqlParseResult();
        insertSqlParseResult.setTableName(sqlInsert.getTargetTable().toString());
        List<String> columnNames = new ArrayList<String>();
        for (SqlNode sqlNode: sqlInsert.getTargetColumnList()) {
            columnNames.add(sqlNode.toString());
        }
        insertSqlParseResult.setColumnNames(columnNames);
        List<String> parameterNames = new ArrayList<String>();
        for (SqlNode sqlNode : sqlInsert.getOperandList()) {
            if (sqlNode instanceof SqlBasicCall) {
                List<SqlNode> operandList = ((SqlBasicCall)sqlNode).getOperandList();
                List<SqlNode> columnValueNodes = ((SqlBasicCall)operandList.get(0)).getOperandList();
                for (SqlNode columnValueNode : columnValueNodes) {
                    parameterNames.add(columnValueNode.toString());
                }
            }
        }
        insertSqlParseResult.setValues(parameterNames);
        return insertSqlParseResult;
    }

    private static void addCondition(SqlBasicCall call, List<String> conditionColumnNames,
                                     List<String> conditionValues) {
        SqlOperator operator = call.getOperator();
        if ("=".equals(operator.getName())) {
            List<SqlNode> operands = call.getOperandList();
            for (SqlNode operand : operands) {
                if (operand instanceof SqlBasicCall) {
                    addCondition((SqlBasicCall)operand, conditionColumnNames, conditionValues);
                }
                else if (operand instanceof SqlIdentifier) {
                    conditionColumnNames.add(operand.toString());
                }
                else if (operand instanceof SqlLiteral) {
                    conditionValues.add(operand.toString());
                }
            }
        }
        else if ("AND".equals(operator.getName())) {
            List<SqlNode> operands = call.getOperandList();
            for (SqlNode operand : operands) {
                if (operand instanceof SqlBasicCall) {
                    addCondition((SqlBasicCall)operand, conditionColumnNames, conditionValues);
                }
            }
        }
        else {
            logger.error("Unsupported operator: {}", operator);
        }
    }

    /**
     * convert update sql parse result.
     * @param updateNode  update node
     * @return update sql parse result
     */
    public static UpdateSqlParseResult convertUpdateSqlParseResult(SqlNode updateNode) {
        SqlUpdate sqlUpdate = (SqlUpdate)updateNode;
        UpdateSqlParseResult updateSqlParseResult = new UpdateSqlParseResult();
        updateSqlParseResult.setTableName(sqlUpdate.getTargetTable().toString());
        SqlBasicCall conditionCall = (SqlBasicCall)sqlUpdate.getCondition();
        List<String> conditionColumnNames = new ArrayList<String>();
        List<String> conditionValues = new ArrayList<String>();
        addCondition(conditionCall, conditionColumnNames, conditionValues);
        updateSqlParseResult.setConditionColumnNames(conditionColumnNames);
        updateSqlParseResult.setConditionValues(conditionValues);

        List<String> columnNames = new ArrayList<String>();
        for (SqlNode sqlNode: sqlUpdate.getTargetColumnList()) {
            columnNames.add(sqlNode.toString());
        }
        updateSqlParseResult.setTargetColumnNames(columnNames);
        List<String> columnValues = new ArrayList<String>();
        for (SqlNode sqlNode : sqlUpdate.getSourceExpressionList()) {
            columnValues.add(sqlNode.toString());
        }
        updateSqlParseResult.setTargetValues(columnValues);
        return updateSqlParseResult;
    }


    protected static SqlParserImplFactory parserImplFactory() {
        return SqlParserImpl.FACTORY;
    }
}
