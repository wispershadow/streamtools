/*
 * Copyright 2018, Zetyun StreamTau All rights reserved.
 */

package com.zetyun.rt.cache.service;

import com.zetyun.rt.models.protocol.ignite.CacheAtomicityModeType;
import com.zetyun.rt.models.protocol.ignite.CacheModeType;
import com.zetyun.rt.models.protocol.ignite.CacheWriteSynchronizationModeType;
import com.zetyun.rt.models.protocol.ignite.IgniteCacheParameters;
import com.zetyun.rt.models.protocol.ignite.IgniteColumnSchema;
import com.zetyun.rt.models.protocol.ignite.IgniteQuerySchema;

import org.apache.ignite.cache.CacheAtomicityMode;
import org.apache.ignite.cache.CacheMode;
import org.apache.ignite.cache.CacheWriteSynchronizationMode;
import org.apache.ignite.cache.QueryEntity;
import org.apache.ignite.cache.QueryIndex;
import org.apache.ignite.configuration.CacheConfiguration;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Set;

import javax.cache.expiry.CreatedExpiryPolicy;
import javax.cache.expiry.Duration;

public class SchemaIgniteCacheService {
    private static final Logger logger = LoggerFactory
            .getLogger(SchemaIgniteCacheService.class);

    private SchemaIgniteCacheService() {}

    /**
     * Get cache configuration.
     * @param igniteCacheParameters  ignite parameter
     * @return  cache configuration
     */
    public static CacheConfiguration getCacheConfiguration(
            IgniteCacheParameters igniteCacheParameters) {
        CacheConfiguration cacheCfg = new CacheConfiguration();
        cacheCfg.setName(igniteCacheParameters.getCacheName());
        setCacheConfigCacheMode(cacheCfg, igniteCacheParameters.getCacheMode());
        if (igniteCacheParameters.needTransaction()) {
            setCacheConfigAtomicityMode(cacheCfg, CacheAtomicityModeType.TRANSACTIONAL);
        }
        else {
            setCacheConfigAtomicityMode(cacheCfg,
                igniteCacheParameters.getAtomicityMode());
        }
        setCacheDataRegionName(cacheCfg, igniteCacheParameters.getDataRegionName());
        setCacheConfigWriteSynchronizationMode(cacheCfg,
                igniteCacheParameters.getWriteSynchronizationMode());
        setCacheConfigBackups(cacheCfg, igniteCacheParameters.getBackups());
        setCacheConfigQueryEntity(cacheCfg, igniteCacheParameters);
        // expired time for the whole cache
        if (igniteCacheParameters.getDuration() != null) {
            Duration duration = new Duration(igniteCacheParameters.getDuration().getTimeUnit(),
                igniteCacheParameters.getDuration().getDurations());
            cacheCfg.setExpiryPolicyFactory(CreatedExpiryPolicy.factoryOf(duration));
        }
        return cacheCfg;
    }

    private static void setCacheConfigCacheMode(CacheConfiguration cacheCfg,
            CacheModeType cmt) {
        if (null != cmt) {
            cacheCfg.setCacheMode(CacheMode.valueOf(cmt.name()));
        }
    }

    private static void setCacheConfigAtomicityMode(CacheConfiguration cacheCfg,
            CacheAtomicityModeType camt) {
        if (null != camt) {
            cacheCfg.setAtomicityMode(CacheAtomicityMode.valueOf(camt.name()));
        }
    }

    private static void setCacheDataRegionName(CacheConfiguration cacheCfg, String dataRegionName) {
        if (null != dataRegionName) {
            cacheCfg.setDataRegionName(dataRegionName);
        }
    }


    private static void setCacheConfigWriteSynchronizationMode(
            CacheConfiguration cacheCfg, CacheWriteSynchronizationModeType cwsmt) {
        if (null != cwsmt) {
            cacheCfg.setWriteSynchronizationMode(CacheWriteSynchronizationMode
                    .valueOf(cwsmt.name()));
        }
    }

    private static void setCacheConfigBackups(CacheConfiguration cacheCfg, int backups) {
        if (backups > 0) {
            cacheCfg.setBackups(backups);
        } else {
            logger.warn("Ignite Cache backup less than 1 or not set, ignore it.");
        }
    }

    private static void setCacheConfigQueryEntity(CacheConfiguration cacheCfg,
            IgniteCacheParameters igniteCacheParameters) {
        QueryEntity queryEntity = new QueryEntity();

        queryEntity.setKeyType(getKeyClass(igniteCacheParameters));

        queryEntity.setValueType(getValueClass(igniteCacheParameters));

        IgniteQuerySchema cacheSchema = igniteCacheParameters.getCacheSchema();
        if (null != cacheSchema
                && null != cacheSchema.getColumns()) {
            LinkedHashMap<String, String> fields = new LinkedHashMap<>();
            boolean isCompositKey = isCompositeKey(cacheSchema);
            if (isCompositKey) {
                queryEntity.setKeyFields(getKeyFields(cacheSchema));
                logger.debug("Query entity key fields built: {}", queryEntity.getKeyFields());
            }
            for (IgniteColumnSchema column : cacheSchema
                    .getColumns()) {
                fields.put(column.getName(), column.getType());
            }
            queryEntity.setFields(fields);
        }

        if (null == igniteCacheParameters.getIndexFieldNames()
                || igniteCacheParameters.getIndexFieldNames().size() == 0) {
            logger.warn("No Index in Ignite Cache Config!");
        } else {
            Collection<QueryIndex> indexes = new ArrayList<>();
            for (String index : igniteCacheParameters.getIndexFieldNames()) {
                indexes.add(new QueryIndex(index));
            }
            queryEntity.setIndexes(indexes);
        }
        cacheCfg.setQueryEntities(Arrays.asList(queryEntity));
    }

    private static boolean isCompositeKey(IgniteQuerySchema schema) {
        int countKey = 0;
        for (IgniteColumnSchema column : schema.getColumns()) {
            if (column.isKey()) {
                countKey ++;
            }
        }
        return countKey > 1;
    }

    private static Set<String> getKeyFields(IgniteQuerySchema schema) {
        Set<String> keyFields = new HashSet<String>();
        for (IgniteColumnSchema column : schema.getColumns()) {
            if (column.isKey()) {
                keyFields.add(column.getName());
            }
        }
        return keyFields;
    }


    private static String getKeyClass(IgniteCacheParameters igniteCacheParameters) {
        String keyType = String.class.getName();
        if (null != igniteCacheParameters.getKeyClass()) {
            keyType = igniteCacheParameters.getKeyClass();
        }
        return keyType;
    }

    private static String getValueClass(IgniteCacheParameters igniteCacheParameters) {
        String valueType = Object.class.getName();
        if (null != igniteCacheParameters.getObjectClass()) {
            valueType = igniteCacheParameters.getObjectClass();
        }
        return valueType;
    }
}
