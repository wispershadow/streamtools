/*
 * Copyright 2018, Zetyun StreamTau All rights reserved.
 */

package com.zetyun.rt.cache.service;

import com.zetyun.rt.common.schema.Schema;
import com.zetyun.rt.sdk.service.sqlcache.SqlCacheTable;
import org.apache.ignite.cache.QueryEntity;
import org.apache.ignite.cache.QueryIndex;
import org.apache.ignite.configuration.CacheConfiguration;
import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.ReflectionUtils;

import java.io.StringWriter;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

public class SqlCacheTableBuilderUtils {
    private static final Logger logger = LoggerFactory.getLogger(SqlCacheTableBuilderUtils.class);
    private static final String CREATE_INDEX_SQL = "CREATE INDEX IF NOT EXISTS %s ON %s (%s)";

    /**
     * build sql cache table from pojo.
     * @param pojoClass  pojo class
     * @param keyAttributes  key attributes
     * @param indexAttributes  index attribute
     * @param <T> generic
     * @return sql cache table
     */
    public static <T> SqlCacheTable buildSqlCacheTableFromPojo(Class<T> pojoClass, List<String> keyAttributes,
                                                               List<String> indexAttributes) {
        logger.info("Start build sql table from pojo, class={}, key attributes={}, "
            + "index attributes={}", pojoClass, keyAttributes, indexAttributes);
        final List<SqlCacheTable.Column<?>> columns = new ArrayList<SqlCacheTable.Column<?>>();
        ReflectionUtils.doWithFields(pojoClass, new ReflectionUtils.FieldCallback() {
            public void doWith(Field field) throws IllegalArgumentException,
                IllegalAccessException {
                columns.add(SqlCacheTable.Column.of(field.getName(), field.getType()));
            }
        }, new ReflectionUtils.FieldFilter() {
            public boolean matches(Field field) {
                return !"class".equals(field.getName());
            }
        });
        List<SqlCacheTable.IndexColumn> keyColumns = new ArrayList<SqlCacheTable.IndexColumn>();
        for (int i = 0; i < keyAttributes.size(); i++) {
            keyColumns.add(buildColumn(pojoClass, keyAttributes.get(i)));
        }
        SqlCacheTable.PrimaryKey primaryKey = SqlCacheTable.PrimaryKey.of(keyColumns);
        List<SqlCacheTable.SecondaryIndex> indices = new ArrayList<SqlCacheTable.SecondaryIndex>();
        for (String indexAttribute : indexAttributes) {
            indices.add(SqlCacheTable.SecondaryIndex.of(buildColumn(pojoClass, indexAttribute)));
        }
        String schemaName = getSchemaName(pojoClass.getName());
        SqlCacheTable result = new SqlCacheTable(schemaName, primaryKey, indices, columns);
        result.setKeyType(getKeyType(keyColumns));
        result.setValueType(pojoClass.getName());
        logger.info("Successfully built sql cache table from pojo: {}", result);
        return result;
    }

    /**
     * build sql table from schema.
     * @param schema schema
     * @return sql cache table
     */
    public static SqlCacheTable buildSqlCacheTableFromSchema(Schema schema) {
        if (schema.getColumns() == null) {
            throw new IllegalArgumentException("No columns defined for schema");
        }
        if (logger.isDebugEnabled()) {
            String schemaColumns = schema.getColumns().stream()
                .map((c) -> { return c.getName(); } )
                .collect(Collectors.joining(","));
            logger.debug("Start building sql table from schema: name={}, columns={}", schema.getName(),
                schemaColumns);
        }
        final List<SqlCacheTable.Column<?>> columns = new ArrayList<SqlCacheTable.Column<?>>();
        schema.getColumns().forEach((c) -> {
            try {
                columns.add(SqlCacheTable.Column.of(c.getName(), Class.forName(c.getType())));
            }
            catch (Exception ex) {
                logger.error("Error building column: " + c.getName(), ex);
            }
        });

        final List<SqlCacheTable.IndexColumn> keyCols =
            new ArrayList<SqlCacheTable.IndexColumn>();
        schema.getColumns().stream().filter((c) -> {
            return c.isKey();
        }).forEach((c) -> {
            try {
                keyCols.add(SqlCacheTable.Column.of(c.getName(), Class.forName(c.getType())));
            }
            catch (Exception ex) {
                logger.error("Error building column: " + c.getName(), ex);
            }
        });
        SqlCacheTable.PrimaryKey primaryKey = SqlCacheTable.PrimaryKey.of(keyCols);
        List<SqlCacheTable.SecondaryIndex> indices = new ArrayList<SqlCacheTable.SecondaryIndex>();
        schema.getColumns().stream().filter((c) -> {
            return c.isIndexable();
        }).forEach((c) -> {
            try {
                SqlCacheTable.SecondaryIndex si = SqlCacheTable.SecondaryIndex.of(
                    Collections.singletonList(SqlCacheTable.Column.of(c.getName(), Class.forName(c.getType())))
                );
                indices.add(si);
            }
            catch (Exception ex) {
                logger.error("Error building column: " + c.getName(), ex);
            }
        });
        SqlCacheTable result = new SqlCacheTable(getSchemaName(schema.getName()), primaryKey, indices, columns);
        result.setKeyType(getKeyType(keyCols));
        result.setValueType(schema.getName());
        logger.info("Successfully built sql cache table from schema: {}", result);
        return result;
    }

    /**
     * build sql table from cache config.
     * @param cacheConfig cache config
     * @return list of sql cache table
     */
    public static List<SqlCacheTable> buildSqlCacheTableFromCacheConfig(CacheConfiguration cacheConfig) {
        Collection<QueryEntity> queryEntities = cacheConfig.getQueryEntities();
        List<SqlCacheTable> result = new ArrayList<SqlCacheTable>();
        queryEntities.forEach((e) -> {
            result.add(buildFromQueryEntity(e));
        });
        return result;
    }

    /**
     * generate create table sql.
     * @param cacheName cache name
     * @param sqlCacheTable sql cache table
     * @return create table sql
     */
    public static String generateCreateTableSql(String cacheName,
                                                SqlCacheTable sqlCacheTable) {
        VelocityEngine engine = new VelocityEngine();
        engine.setProperty(VelocityEngine.RESOURCE_LOADER, "class");
        engine.setProperty("class.resource.loader.class",
            "org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader");
        engine.init();
        Template template = engine.getTemplate("createtable.vtl");
        VelocityContext vlCtx = new VelocityContext();
        vlCtx.put("sqltable", sqlCacheTable);
        vlCtx.put("templatename", "template");
        vlCtx.put("sqltypemapper", new IgniteSqlTypeMapper());
        vlCtx.put("cachename", cacheName);
        StringWriter writer = new StringWriter();
        template.merge(vlCtx, writer);
        return writer.toString();
    }

    /**
     * generate create index sql.
     * @param cacheName cache name
     * @param sqlCacheTable sql cache table
     * @return create index sql
     */
    public static List<String> generateCreateIndexSql(String cacheName,
                                                      SqlCacheTable sqlCacheTable) {
        List<SqlCacheTable.SecondaryIndex> indices = sqlCacheTable.getIndices();
        if (indices == null || indices.isEmpty()) {
            return Collections.emptyList();
        }
        else {
            List<String> createIndexSqls = new ArrayList<String>();
            for (int i = 0; i < indices.size(); i++) {
                SqlCacheTable.SecondaryIndex index = indices.get(i);
                String indexName = String.join("_", new String[]{"idx", sqlCacheTable.getName(), String.valueOf(i)});
                List<String> colNameList = index.columns().stream().map((c) -> { return c.name(); })
                    .collect(Collectors.toList());
                String columnNames = String.join(",", colNameList);
                createIndexSqls.add(String.format(CREATE_INDEX_SQL, indexName, sqlCacheTable.getName(),
                    columnNames));
            }
            logger.debug("Generated index sqls: {}", createIndexSqls);
            return createIndexSqls;
        }
    }

    /**
     * generate create index sql based on difference between previous and current sql table.
     * @param cacheName cache name
     * @param prevTable  previous sql table
     * @param sqlCacheTable current sql table
     * @return create index sql
     */
    public static List<String> generateCreateIndexSql(String cacheName,
                                                      SqlCacheTable prevTable, SqlCacheTable sqlCacheTable) {
        List<SqlCacheTable.SecondaryIndex> indices = sqlCacheTable.getIndices();
        if (indices == null || indices.isEmpty()) {
            return Collections.emptyList();
        }
        else {
            List<SqlCacheTable.SecondaryIndex> newIndices = indices.stream().filter((si) -> {
                List<SqlCacheTable.SecondaryIndex> prevIndices = Optional.ofNullable(prevTable.getIndices())
                    .orElseGet(Collections::emptyList);
                return prevIndices.stream().noneMatch((pi) -> {
                    //support only happy case, if two indices has partially column overlapping,
                    // we will consider it as matching and will not create index again
                    return matchIndex(pi, si);
                });
            }).collect(Collectors.toList());
            List<String> createIndexSqls = new ArrayList<String>();
            for (int i = 0; i < newIndices.size(); i++) {
                SqlCacheTable.SecondaryIndex index = indices.get(i);
                String indexName = String.join("_", new String[]{"idx", sqlCacheTable.getName(), String.valueOf(i)});
                List<String> colNameList = index.columns().stream().map((c) -> { return c.name(); })
                    .collect(Collectors.toList());
                String columnNames = String.join(",", colNameList);
                createIndexSqls.add(String.format(CREATE_INDEX_SQL, indexName, sqlCacheTable.getName(),
                    columnNames));
            }
            logger.debug("Generated index sqls: {}", createIndexSqls);
            return createIndexSqls;
        }
    }

    public static boolean isCompartibleChange(SqlCacheTable prevTable,
                                              SqlCacheTable currentTable) {
        return true;
    }

    /**
     * generate alter table sql base on difference of previous and current sql table.
     * @param cacheName cache name
     * @param prevTable previous table
     * @param currentTable current table
     * @return list of alter table sql
     */
    public static List<String> generateAlterTableSql(String cacheName,
                                                     SqlCacheTable prevTable, SqlCacheTable currentTable) {
        //if there are new columns added
        List<String> result = new ArrayList<String>();
        List<SqlCacheTable.Column> addedCols = currentTable.getColumns().stream().filter((cc) -> {
            return prevTable.getColumns().stream().noneMatch((pc) -> {
                return pc.name().equalsIgnoreCase(cc.name());
            });
        }).collect(Collectors.toList());
        VelocityEngine engine = new VelocityEngine();
        engine.setProperty(VelocityEngine.RESOURCE_LOADER, "class");
        engine.setProperty("class.resource.loader.class",
            "org.apache.velocity.runtime.resource.loader.ClasspathResourceLoader");
        engine.init();
        Template template = engine.getTemplate("altertable.vtl");
        VelocityContext vlCtx = new VelocityContext();
        vlCtx.put("tableName", currentTable.getName());
        vlCtx.put("sqltypemapper", new IgniteSqlTypeMapper());
        for (SqlCacheTable.Column col: addedCols) {
            vlCtx.put("col", col);
            StringWriter writer = new StringWriter();
            template.merge(vlCtx, writer);
            result.add(writer.toString());
        }
        return result;
    }


    private static SqlCacheTable buildFromQueryEntity(QueryEntity queryEntity) {
        logger.debug("Start building sql table from query entity: {}", queryEntity);
        final List<SqlCacheTable.Column<?>> columns = new ArrayList<SqlCacheTable.Column<?>>();
        queryEntity.getFields().forEach((k, v) -> {
            try {
                columns.add(SqlCacheTable.Column.of(k, Class.forName(v)));
            }
            catch (Exception ex) {
                logger.error("Error building column: " + k, ex);
            }
        });
        final List<SqlCacheTable.IndexColumn> keyCols =
            new ArrayList<SqlCacheTable.IndexColumn>();
        String keyFieldName = queryEntity.getKeyFieldName();
        if (keyFieldName != null) {
            try {
                String keyFieldType = queryEntity.getFields().get(keyFieldName);
                keyCols.add(SqlCacheTable.Column.of(keyFieldName, Class.forName(keyFieldType)));
            }
            catch (Exception ex) {
                logger.error("Error building column: " + keyFieldName, ex);
            }
        }
        else {
            Set<String> keyFields = queryEntity.getKeyFields();
            if (keyFields != null && keyFields.size() > 0) {
                keyFields.forEach((k) -> {
                    try {
                        String keyFieldType = queryEntity.getFields().get(k);
                        keyCols.add(SqlCacheTable.Column.of(k, Class.forName(keyFieldType)));
                    }
                    catch (Exception ex) {
                        logger.error("Error building column: " + k, ex);
                    }
                });
            }
        }

        List<SqlCacheTable.SecondaryIndex> indices = new ArrayList<SqlCacheTable.SecondaryIndex>();
        Collection<QueryIndex> queryIndices = queryEntity.getIndexes();
        if (queryIndices != null && queryIndices.size() > 0) {
            queryIndices.forEach((q) -> {
                List<SqlCacheTable.IndexColumn> indexCols = new ArrayList<SqlCacheTable.IndexColumn>();
                for (String fieldName : q.getFieldNames()) {
                    try {
                        String keyFieldType = queryEntity.getFields().get(fieldName);
                        indexCols.add(SqlCacheTable.Column.of(fieldName, Class.forName(keyFieldType)));
                    }
                    catch (Exception ex) {
                        logger.error("Error building column: " + fieldName, ex);
                    }
                }
                SqlCacheTable.SecondaryIndex secondaryIndex = SqlCacheTable.SecondaryIndex.of(indexCols);
                indices.add(secondaryIndex);
            });
        }
        String tableName = queryEntity.getTableName();
        SqlCacheTable sqlCacheTable = new SqlCacheTable(tableName, SqlCacheTable.PrimaryKey
            .of(keyCols), indices, columns);
        sqlCacheTable.setKeyType(queryEntity.getKeyType());
        sqlCacheTable.setValueType(queryEntity.getValueType());
        logger.info("Successfully built sql cache table from queryEntity: {}", sqlCacheTable);
        return sqlCacheTable;
    }

    private static <T> SqlCacheTable.Column buildColumn(Class<T> pojoClass, String attributeName) {
        Field attributeField = ReflectionUtils.findField(pojoClass, attributeName);
        return SqlCacheTable.Column.of(attributeName, attributeField.getType());
    }

    private static String getKeyType(Iterable<SqlCacheTable.IndexColumn> keyColumns) {
        Iterator<SqlCacheTable.IndexColumn> keyColIter = keyColumns.iterator();
        SqlCacheTable.IndexColumn firstCol = keyColIter.next();
        String keyType = firstCol.column().type().getName();
        if (keyColIter.hasNext()) {
            return null;
        }
        return keyType;
    }

    private static String getSchemaName(String fullClassName) {
        String[] arr = fullClassName.split("\\.");
        if (arr.length > 0) {
            return arr[arr.length - 1];
        }
        else {
            return fullClassName;
        }
    }

    private static boolean matchIndex(SqlCacheTable.SecondaryIndex si1, SqlCacheTable.SecondaryIndex si2) {
        List<SqlCacheTable.IndexColumn> indexColumns1 = si1.columns();
        List<SqlCacheTable.IndexColumn> indexColumns2 = si2.columns();
        return indexColumns1.stream().noneMatch((c1) -> {
            return indexColumns2.stream().anyMatch((c2) -> {
                return c2.name().equals(c1.name());
            });
        });
    }


}
