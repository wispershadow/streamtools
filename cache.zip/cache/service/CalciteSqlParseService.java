package com.zetyun.rt.cache.service;

import org.apache.calcite.sql.SqlNode;
import org.apache.commons.collections.map.LRUMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public class CalciteSqlParseService implements  SqlParseService {
    private static final Logger logger = LoggerFactory.getLogger(CalciteSqlParseService.class);
    private final LRUMap sqlParseCache = new LRUMap(1000);
    private final ReadWriteLock sqlParseLock = new ReentrantReadWriteLock();

    /**
     * parse an insert sql. if the sql is invalid, it will return InsertSqlParseResult.INVALID_RESULT
     * @param insertSql  insert sql
     * @return insert sql parse result
     */
    public InsertSqlParseResult parseInsertSql(String insertSql) {
        sqlParseLock.readLock().lock();
        try {
            InsertSqlParseResult result = (InsertSqlParseResult) sqlParseCache.get(insertSql);
            if (result != null) {
                return result;
            }
            sqlParseLock.readLock().unlock();
            sqlParseLock.writeLock().lock();
            try {
                logger.debug("Parse sql by calcite: {}", insertSql);
                SqlNode insertRootNode = CalciteSqlUtils.getSqlParser(insertSql).parseQuery();
                result = CalciteSqlUtils.convertInsertSqlParseResult(insertRootNode);
                sqlParseCache.put(insertSql, result);
                return result;
            }
            catch (Exception ex) {
                logger.error("Error parse sql " + insertSql, ex);
                result = InsertSqlParseResult.INVALID_RESULT;
                sqlParseCache.put(insertSql, result);
                return result;
            }
            finally {
                sqlParseLock.readLock().lock();
                sqlParseLock.writeLock().unlock();
            }
        }
        finally {
            sqlParseLock.readLock().unlock();
        }
    }

    /**
     * parse an update sql. if the sql is invalid, it will return UpdateSqlParseResult.INVALID_RESULT
     * @param updateSql
     * @return
     */
    public UpdateSqlParseResult parseUpdateSql(String updateSql) {
        sqlParseLock.readLock().lock();
        try {
            UpdateSqlParseResult result = (UpdateSqlParseResult) sqlParseCache.get(updateSql);
            if (result != null) {
                return result;
            }
            sqlParseLock.readLock().unlock();
            sqlParseLock.writeLock().lock();
            try {
                logger.debug("Parse sql by calcite: {}", updateSql);
                SqlNode updateRootNode = CalciteSqlUtils.getSqlParser(updateSql).parseQuery();
                result = CalciteSqlUtils.convertUpdateSqlParseResult(updateRootNode);
                sqlParseCache.put(updateSql, result);
                return result;
            }
            catch (Exception ex) {
                logger.error("Error parse sql " + updateSql, ex);
                result = UpdateSqlParseResult.INVALID_RESULT;
                sqlParseCache.put(updateSql, result);
                return result;
            }
            finally {
                sqlParseLock.readLock().lock();
                sqlParseLock.writeLock().unlock();
            }
        }
        finally {
            sqlParseLock.readLock().unlock();
        }
    }

}
