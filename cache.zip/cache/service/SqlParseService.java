package com.zetyun.rt.cache.service;

public interface SqlParseService {
    public InsertSqlParseResult parseInsertSql(String insertSql);

    public UpdateSqlParseResult parseUpdateSql(String updateSql);
}
