package com.zetyun.rt.cache.service;

import java.util.List;

public class InsertSqlParseResult {
    public static InsertSqlParseResult INVALID_RESULT = new InsertSqlParseResult();
    private String tableName;
    private List<String> columnNames;
    private List<String> values;

    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public List<String> getColumnNames() {
        return columnNames;
    }

    public void setColumnNames(List<String> columnNames) {
        this.columnNames = columnNames;
    }

    public List<String> getValues() {
        return values;
    }

    public void setValues(List<String> values) {
        this.values = values;
    }
}
