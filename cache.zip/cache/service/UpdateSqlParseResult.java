package com.zetyun.rt.cache.service;

import java.util.List;

public class UpdateSqlParseResult {
    public static UpdateSqlParseResult INVALID_RESULT = new UpdateSqlParseResult();
    private String tableName;
    private List<String> targetColumnNames;
    private List<String> targetValues;
    private List<String> conditionColumnNames;
    private List<String> conditionValues;

    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public List<String> getTargetColumnNames() {
        return targetColumnNames;
    }

    public void setTargetColumnNames(List<String> targetColumnNames) {
        this.targetColumnNames = targetColumnNames;
    }

    public List<String> getTargetValues() {
        return targetValues;
    }

    public void setTargetValues(List<String> targetValues) {
        this.targetValues = targetValues;
    }

    public List<String> getConditionColumnNames() {
        return conditionColumnNames;
    }

    public void setConditionColumnNames(List<String> conditionColumnNames) {
        this.conditionColumnNames = conditionColumnNames;
    }

    public List<String> getConditionValues() {
        return conditionValues;
    }

    public void setConditionValues(List<String> conditionValues) {
        this.conditionValues = conditionValues;
    }
}
